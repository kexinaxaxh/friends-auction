-- FRIENDS AUCTION MVP: secure room creation and joining
-- Run in Supabase SQL Editor AFTER the four foundation tables exist.
-- Safe to rerun: replaces only these two named functions.

create or replace function public.create_auction_room(
  p_name text,
  p_display_name text,
  p_budget bigint,
  p_increment bigint,
  p_squad_size integer,
  p_max_players integer
)
returns public.auction_rooms
language plpgsql
security definer
set search_path = ''
as $$
declare
  v_user uuid := auth.uid();
  v_room public.auction_rooms;
  v_name text := left(trim(coalesce(p_name, 'Friends Auction')), 48);
  v_display text := left(trim(coalesce(p_display_name, 'Player')), 24);
begin
  if v_user is null then raise exception 'Please sign in first.'; end if;
  if p_budget is null or p_budget < 1 or p_budget > 9000000000000000 then raise exception 'Budget is invalid.'; end if;
  if p_increment is null or p_increment < 1 or p_increment > p_budget then raise exception 'Bid increment is invalid.'; end if;
  if p_squad_size is null or p_squad_size < 0 or p_squad_size > 500 then raise exception 'Squad size is invalid.'; end if;
  if p_max_players is null or p_max_players < 2 or p_max_players > 100 then raise exception 'Room player limit must be between 2 and 100.'; end if;
  if v_name = '' then v_name := 'Friends Auction'; end if;
  if v_display = '' then v_display := 'Player'; end if;
  insert into public.auction_rooms(host_id,name,starting_budget,bid_increment,squad_size,max_players)
  values(v_user,v_name,p_budget,p_increment,p_squad_size,p_max_players)
  returning * into v_room;
  insert into public.auction_members(room_id,user_id,display_name,budget_remaining)
  values(v_room.id,v_user,v_display,p_budget);
  return v_room;
end;
$$;

create or replace function public.join_auction_room(
  p_code text,
  p_display_name text
)
returns public.auction_rooms
language plpgsql
security definer
set search_path = ''
as $$
declare
  v_user uuid := auth.uid();
  v_room public.auction_rooms;
  v_display text := left(trim(coalesce(p_display_name, 'Player')), 24);
  v_count integer;
begin
  if v_user is null then raise exception 'Please sign in first.'; end if;
  if coalesce(trim(p_code),'') = '' then raise exception 'Enter a room code.'; end if;
  select * into v_room from public.auction_rooms
    where room_code = upper(trim(p_code)) for update;
  if not found then raise exception 'Room code not found.'; end if;
  if v_room.status <> 'waiting' then raise exception 'This room has already started.'; end if;
  if exists(select 1 from public.auction_members where room_id=v_room.id and user_id=v_user) then
    return v_room;
  end if;
  select count(*) into v_count from public.auction_members where room_id=v_room.id;
  if v_count >= v_room.max_players then raise exception 'This room is full.'; end if;
  if v_display = '' then v_display := 'Player'; end if;
  insert into public.auction_members(room_id,user_id,display_name,budget_remaining)
  values(v_room.id,v_user,v_display,v_room.starting_budget);
  return v_room;
end;
$$;

revoke all on function public.create_auction_room(text,text,bigint,bigint,integer,integer) from public, anon;
revoke all on function public.join_auction_room(text,text) from public, anon;
grant execute on function public.create_auction_room(text,text,bigint,bigint,integer,integer) to authenticated;
grant execute on function public.join_auction_room(text,text) to authenticated;

-- Realtime events for the room list and member roster.
alter publication supabase_realtime add table public.auction_rooms;
alter publication supabase_realtime add table public.auction_members;
